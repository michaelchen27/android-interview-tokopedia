package com.tokopedia.core

object GlobalConfig {
    @JvmField
    var DEBUG = true
}

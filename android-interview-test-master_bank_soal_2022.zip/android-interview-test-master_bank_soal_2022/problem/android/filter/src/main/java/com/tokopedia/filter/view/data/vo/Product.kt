package com.tokopedia.filter.view.data.vo

data class Product(
    val `data`: Data
)
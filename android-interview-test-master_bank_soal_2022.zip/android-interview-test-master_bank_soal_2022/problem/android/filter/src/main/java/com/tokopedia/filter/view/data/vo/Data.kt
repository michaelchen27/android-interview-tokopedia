package com.tokopedia.filter.view.data.vo

data class Data(
    val products: List<ProductX>
)
package com.tokopedia.filter.view.data.vo

data class Shop(
    val city: String,
    val id: Int,
    val name: String
)
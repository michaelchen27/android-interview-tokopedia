package com.tokopedia.maps.vo


import com.google.gson.annotations.SerializedName

class Country : ArrayList<CountryItem>()
package com.tokopedia.maps.vo


import com.google.gson.annotations.SerializedName

data class Currencies(
    @SerializedName("PEN")
    val pEN: PEN
)
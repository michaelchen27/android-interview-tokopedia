package com.tokopedia.maps

internal object MapsConstant {
    const val BASE_URL = "https://restcountries.com/v3.1/"
}
package com.tokopedia.maps.vo


import com.google.gson.annotations.SerializedName

data class Gini(
    @SerializedName("2019")
    val x2019: Double
)